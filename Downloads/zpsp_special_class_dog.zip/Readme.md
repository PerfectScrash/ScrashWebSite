## [ZPSp] Special Class: Dog

* **Description:**
	Dog are smaller and furious (Walk like zombie crawler), humans can kill with knife only (In Dog Rounds)
* **Cvars:**<br/>
	zp_dog_minplayers "2" - Min Players for start a Dog round<br/>
	zp_dog_damage_multi "2" - Knife damage multi for Dog

* **Change Log:**
	* 1.0:
		- First Release

	* 1.1:
		- Fixed Ambience Sound
		- Optimized Code
		- 20/12 Fix: Fixed Error log on "event_round_started"

	* 1.2:
		- ZPSp 4.5 Full support

	* 1.3:
		- Fix Server crashes when use "engclient_cmd" in bots

### Download Resources: https://github.com/PerfectScrash/ZP-Special-Mods/raw/master/Dog/resources.zip
