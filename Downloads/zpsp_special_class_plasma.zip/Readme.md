## [ZPSp] Special Class: Plasma

* **Description:**
Give a player a one Plasma Rifle

* **Cvars:**<br/>
zp_plasma_minplayers "2" - Min Players for Start a Plasma Mode

* **Change Log:**<br/>
* 1.0:<br/>- First Release

* 1.1:<br/>
	- Fixed Ambience Sound<br/>
	- Fixed v_model of Plasma Rifle<br/>
	- Added Draw Sound in v_model<br/>
	- Plasma Rifle Can give Ammo packs (Works only in Zombie Plague Special 4.4 or higher)

* 1.2:<br/>
	- Fixed Zombie health (Some times zombies have same health as first zombie)<br/>
	- Fixed Bug that player sometimes don't turn into plasma when round start

* 1.3:<br/>
	- ZPSp 4.5 Support <br/>
	- Engine module is not used more here
	
### Download Resources: https://github.com/PerfectScrash/ZP-Special-Mods/raw/master/Plasma/resources.zip
