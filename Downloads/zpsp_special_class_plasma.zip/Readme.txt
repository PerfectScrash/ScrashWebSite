## [ZPSp] Special Class: Plasma

* **Description:**
Give a player a one Plasma Rifle

* **Cvars:**
zp_plasma_minplayers "2" - Min Players for Start a Plasma Mode

* **Change Log:**
* 1.0:<br/>- First Release

* 1.1:
        - Fixed Ambience Sound<br/>
        - Fixed v_model of Plasma Rifle<br/>
        - Added Draw Sound in v_model<br/>
        - Plasma Rifle Can give Ammo packs (Works only in Zombie Plague Special 4.4 or higher)

