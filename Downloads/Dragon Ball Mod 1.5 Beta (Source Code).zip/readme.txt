  Latest stable Version: https://forums.alliedmods.net/showthread.php?t=235332
  
  1.5 Beta Resources: https://www.dropbox.com/s/x9xuq1z3z6658gw/Dragon%20Ball%20Mod%201.5%20%28Resources%20File%29.zip?dl=0
  
    			 [Dragon Ball Mod]
				
				** Description of Mod: 
	      Each character has a power and has a different Transformation and which 
			has a similar power as Super Buu and Broly.
			
	\----------------------------------------------------------------------------------------/
			
			** Description of Characters (Heroes): 
		* Goku : 
			- Transformations and Attacks :
			Super Saiajin : Unleash a Simple Ki - Blast
			Super Saiajin 2 : Unleash an Simple Blue Kamehameha
			Super Saiajin 3 : Unleash an Dragon First
			Super Saiajin 4 : Unleash an Enhanced 10x Kamehameha
			Miggate'no Gokkui + SSJ4 ("Super Saiajin 5") : Unleash a Spirit Bomb
		
		* Vegeta :
			- Transformations and Attacks :
			Super Saiajin : Unleash a Simple Ki - Blast
			Super Saiajin 2 : Unleash an Garlic Gun
			Super Saiajin Blue : Unleash a Final Flash
			Super Saiajin 4 : Unleash a Final Shine Attack
		
		* Gohan (Teen): 
			- Transformations and Attacks :
			Attack 1 : Simple Unleash Ki - Blast 
			Super Saiajin : Unleash an Masenko
			Super Saiajin 2 : Unleash an Kamehameha
		
		* Krilin :
			- Attacks :
			Attack 1 : Unleash a Simple Ki - Blast
			Attack 2 : Unleash an Kamehameha
			Attack 3 : Unleash an Destruction Disc
		
		* Picolo :
			- Attacks :
			Attack 1 : Unleash a Simple Ki - Blast
			Attack 2 : Unleash an Masenko
			Attack 3 : Unleash a Special Beam Cannon
			
	\----------------------------------------------------------------------------------------/
			
			** Description of Character (Villains): 
			
		* Frieza :
			- Transformations and Attacks :
			1st Transformation : Unleash a Simple Ki - Blast
			Transformation 2 : Unleash a Death Beam
			Final Form : Unleash an Destruction Disc (Similar Krilin the only purple)
			Golden Form : Unleash a Death Ball
		
		* Cell:
			- Transformations and Attacks :
			Semi - Perfect Form : Unleash a Simple Ki - Blast
			Perfect Form : Unleash a Death Beam
			Super Perfect Form : Unleash a Green Kamehameha
		
		* Super Buu & Broly :
			- Attacks :
			Attack 1 : Unleash an Galitgun
			Attack 2 : Unleash a Final Flash
			Attack 3 : Unleash a Big Bang
			Attack 4 : Unleash a Death Ball
		
		* Omega Sheron (Or Li - Shen - Long) :
			- Transformations and Attacks :
			3 Dragon Balls Absorbed : Unleash a Simple Ki - Blast
			5 Dragon Balls Absorbed : Unleash an Dragon Thunder 
			All Dragon Balls Absorbed : Unleash an Minus Energy Power Ball
			
	\----------------------------------------------------------------------------------------/			
				  ** Credits:

		- Version Created By: [P]erfec[T] [S]cr[@]s[H]
		- Thanks Vittu For Goku Hero´s Code
		- Thanks green name for some sprites and sounds
		- Thanks addons_zz for help with cache itens 
		
	\----------------------------------------------------------------------------------------/
		
				** Change Log:
		v 1.0:
			* First Relase
				
		v 1.1: 
			* Fixed Some Bugs
			* Optimized Code
			* Added .cfg File

		v 1.2:
			* Fixed Health's Engine Bug
			* Fixed Bug of Reable Channel Overflow with powerup effect
			* Optimized Code

		v 1.3: (BIG UPDATE)
			* Added Player Models
			* Added Sounds of Attacks/Tranformations for all characters (Execpt Omega Shenron)
			* Added Knife Sound
			* Fixed Some Bugs
			* Etc.
		v 1.4:
			* Fixed Sounds
			* Use button in FM_emitsound
			* Fixed Some bugs
			* Added Join Spec Option
			* Added More Superbuu Models

		v 1.5 (Beta)
			* Cached Itens for reduce lag/delay (Thanks addons_zz)
			* No Amx 1.8.2 Suport now (Now requires AMX 1.8.3 or higher)
			* Removed set_user_model plugin needed (Because of cstrike module fixes)
			* Optimed Code
			* Removed Redudant Sprites
			* DBZ tag changed to DBM 
			* Added Omega Shenron Sounds
			* Added Frieza's Golden Form
			* Changed Vegeta SSJ3 to Vegeta SSJ Blue
			* Power up description updated on lang (Lang Updated)
