## [ZPSp] Extra Item: Frost M4A1

### Description:
- Can frost zombies with this weapon

### Requeriments:
- Zombie Plague Special 4.5

### Credits:
- Raheem: Original version
- ShaunCraft15: Custom trail
- Perfect Scrash: Otimization and for ZPSp 4.5 version

### Changelog:
* 1.0: 
    - First Release
* 1.1:
    - Fixed bug on buy frost m4a1 when you have m4a1 as primary
    - Fixed bug on damage multi not working in special zombies
    - Fixed Small bug on damage to frost hud