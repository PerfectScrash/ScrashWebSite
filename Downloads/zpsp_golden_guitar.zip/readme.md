## [ZPSp] Extra: Golden Guitar

### Description:
- Give a player a Weapon Golden Guitar

### Requeriments:
- Zombie Plague Special 4.5 or higher

### Cvars:
- zp_golden_guitar_dmg "1.5"		// Weapon Damage Multipler
- zp_golden_guitar_recoil "0.1"     // Weapon Recoil
- zp_golden_guitar_clip "40"		// Weapon Clip Ammo
- zp_golden_guitar_spd "1.0"		// Weapon Speed Shoot
- zp_golden_guitar_ammo "180"		// Weapon Ammo
- zp_golden_guitar_bullets "1"      // Gold tracer on bullets (0 - Disable | 1 - Enable)

### Credits:
- Unknow Author: For Rock Guitar .sma
- ShaunCraft15: Custom bullet tracer
- Perfect Scrash: Otimization and for ZPSp 4.5 version

### Changelog:
* 1.0:
    - First Version