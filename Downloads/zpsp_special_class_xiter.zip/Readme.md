# [ZPSp] Special Class: Xiter 
	
## Description:
	This Special Class have a f***ing Speed Hack and great damage and use against zombies

## Cvars:
	- zp_xiter_minplayers 2 		// Min players for start a Xiter gamemode
	- zp_xiter_damage_multi 2.0 	// Damage multi for Xiter's every weapon
	- zp_xiter_weapon_rate 0.05		// Speed of Shoots
