/*==================================================================================================================================================================================================================================================
											[Plugin Edited/Made By]

||||||||             |||||||							||||||||             |||||||	     ||||||||		|||||||			     ||||||||		|||||||            ||||||||	     ||||||||
||	||||||||||| 	  ||		     	     ||||			||	||||||||||||	  ||	     ||	     ||||||||||	     ||			     ||	    ||||||||||||     ||		   ||	   ||	   ||	   ||
||	||	  ||	  ||			     ||				||           ||		  ||	     ||	    ||		     ||			     ||	    ||	      ||     ||            ||	   ||	   ||	   ||
||	||	   || 	  ||			     ||				||           ||		  ||	     ||	    ||		     ||  		     ||	    || |||||  ||     ||            ||	   ||	   ||	   ||
||	||	   || 	  ||	||||||||  |||||||| ||||||| ||||||||  ||||||||	||           ||		  ||	     ||      ||||||||||	     ||  ||||||||  ||||||||  ||     || || ||  ||     ||  |||||||   ||	   ||||||||||	   ||
||	||||||||||||  	  ||	||    ||  ||	     ||    ||    ||  ||		||           ||		  ||	     ||		      ||     ||	 ||	   ||	     ||	    || |||||| ||     || ||         ||	   ||	   ||	   ||
||	||	      	  ||	||||||||  ||	     ||    ||||||||  ||		||           ||		  ||	     ||		      ||     ||	 ||	   ||	     ||     ||	      ||     || ||||||||   ||	   ||	   ||	   ||
||	||	      	  ||	||        ||	     ||    ||        ||		||           ||		  ||	     ||	     ||||||||||	     ||	 ||        ||        ||     ||||||||||||     ||        ||  ||	   ||	   ||	   ||
||	||	      	  ||	||||||||  ||	     ||    ||||||||  ||||||||	||||||||	     |||||||	     ||||||||		|||||||  ||||||||  ||        ||||||||		||||||| ||||||||   ||||||||	     ||||||||
||||||||	     |||||||

=|-----------------------------------------------------------------------------------------------------------------------------------------------------|=
				
		----------[Change Logs]----------
* 1.0:
	- First Version.
* 1.1:
	- Fixed bug that Lasermine Dont Works.
	- Show Lasermine Owner Name.
	- Make Random Color Of Glow/Line in raibom style (When Enable).
* 1.2:
	- Fixed Bug: When Player Die and Lasermine dont removed
	- Fixed Bug: Cant Plant If your Lasermine destroyed one time
* 1.3:
	- Added: Solid Mode
* 1.4:
	- Fixed Some Bugs
	- Added Natives and Forwards
* 2.0:
	- Fixed Some Error Logs.
* 2.1:
	- Fixed Some Bugs.
	- Added More Cvars for Easily Config.
* 2.2:
	- Fixed More Error Logs
	- Added Lasermine Main Menu for Personal Configuration
* 2.3:
	- Fixed bug when R,G,B are equal to 0 for make line invisible
	- Fixed bug when some time radius crashes the server
	- New Main Menu Options (Choose Sprites/Models)
* 3.0:
	- Added More Models
	- Added Lang Support
* 3.1:
	- Added More Sprites
* 3.2/3.3:
	- Fixed More Error Logs
	- Added More Cvars for Easily Config.
* 3.4:
	- Fixed More Error Logs
	- Added Model "Perfect Lasermine"
* 4.0:
	- Fixed Some error logs
	- Fixed Small bug when plant lasermine and lasermine does not stay in the wall
	- Added one Cvar for define the max distance for remove the Lasermine
	- Adicionado um esquema para matar o Boss Na Lasermine
	- Added mode for lasermine can kill entities (Like Oberon Boss and Others)
* 4.1:
	- Improved Code
	- Fixed Lang
* 4.2:
	- Added more Models/Sprites for Lasermine
	- Added Realistic Detail of Lasermine (Cut the laser mine when it passes over)
	- End of Style "Rainbow" for Reduce Lag
	- Fixed Native/Cvar Error Logs
	- Improved Code
	- Fixed Forward "zp_fw_lm_planted_pre"
	- Removed CZ Tutor Print (Because some steam players have bug when show tutor in screen)
* 4.3:
	- Fixed Error Log
	- Fixed Neon Color Line Sprite (Color are rights. Now white color are white color even and not yellow color)
	- Improved Dotted Line Sprite (More Dotts are appears now)
	- Added cvars for enable lasermine in certain gamemode.
	- Added Skin System
	- Removed Red Eye Model
	- Alien 2 (Dark Alien) are now skin of Alien 1
	- Added Eyeball and Infinity Gauntlet LM Model
	- Now are 9 models in 1 mdl (Need Update Resources)
	- Some with Sprites - 10 sprites in 1 .spr (Need Update Resources)
	- Added Sprites: Heartbeat, Love Heart, Amazing Stars, Skull
	- Added Remove Glow Option (In choose glow menu)
	- Updated Lang
	- Added Extra Item Configuration 
	- Added ZP Version Configuration
	- Added Many Cvars (See the ltm_cvars.cfg)
	- Added Lasermine Mode (Simple Explode or Normal lasermine)

	----------[Credits]----------
- [P]erfec[T] [S]cr[@]s[H]: For Editing and Posting this Plugin
- SandStriker: For Original Version

Need Help to install see the link: https://forums.alliedmods.net/showthread.php?t=302419

=|---------------------------------------------------------------------------------------------------------------------------------------------------------|=					
										      -------------||-------------
====================================================================================================================================================================================================================================================*/