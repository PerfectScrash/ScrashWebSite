# [ZPSp] Addon: Thunder Weapons

### Description:
- Give a user an thunder weapon after killing some zombie

### Cvars:
- zp_thunder_weapon_dmg - Weapon Damage Multipler

### Change Log:
* 1.0:
	- Fist Release
* 1.1:
	- Fixed Small bug when you kill a zombie, the weapon model dont change
* 1.2:
	- Small bug fix (Interference with X Custom weapon)