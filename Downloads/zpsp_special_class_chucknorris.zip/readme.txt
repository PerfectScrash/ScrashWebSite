## [ZPSp] Special Class: Chuck Norris

* **Description:**
	Nothing is able to stop the invincible Chuck Norris

* **Cvars:**
	zp_chuck_norris_minplayers "2" ; Minimun of players for start a Chuck Norris Mod

* **Change log:**

* 1.0: 
  - First Release

* 1.1:
  - Fixed Ambience Bug
  - Fixed Frozen Bug (Not Frozing in some times)
  - Added More messages
