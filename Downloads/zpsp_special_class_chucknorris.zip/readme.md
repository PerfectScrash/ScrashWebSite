## [ZPSp] Special Class: Chuck Norris

* **Description:**
	Nothing is able to stop the invincible Chuck Norris

* **Cvars:** </br>
	zp_chuck_norris_minplayers "2" ; Minimun of players for start a Chuck Norris Mod

* **Change log:**

* 1.0: 
  - First Release

* 1.1:
  - Fixed Ambience Bug
  - Fixed Frozen Bug (Not Frozing in some times)
  - Added More messages

* 1.2:
  - Fixed Zombie health (Some times zombies have same health as first zombie)
  - Fixed Bug that player sometimes don't turn into plasma when round starts

* 1.3:
  - Added Support for ZPSp 4.5
