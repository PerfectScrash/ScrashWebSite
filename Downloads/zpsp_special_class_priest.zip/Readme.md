## [ZPSp] Special Class: Priest

* **Description:**
  Removes a Demon from Zombie with a Holy Grenade

* **Cvars:**<br/>
  zp_priest_minplayers "2" - Min Players for start a Priest Mod<br/>
  zp_priest_damage_multi "1.5" - Knife Damage Multi

* **Change Log:**
  * 1.0:
    - First Release

  * 1.1:
    - Fixed Ambience
    - Added p_model

  * 1.2:
    - Fixed Zombie health (Some times zombies have same health as first zombie)
    - Fixed Bug that player sometimes don't turn into plasma when round starts
  
  * 1.3:
    - ZPSp 4.5 Support
    - Added P_ and W_ model support for antidote bomb
    
### Download Resources: https://github.com/PerfectScrash/ZP-Special-Mods/raw/master/Priest/resources.zip
