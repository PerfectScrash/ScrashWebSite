## [ZPSp] Special Class: Priest

* **Description:**
  Removes a Demon from Zombie with a Holy Grenade

* **Cvars:**<br/>
  zp_priest_minplayers "2" - Min Players for start a Priest Mod<br/>
  zp_priest_damage_multi "1.5" - Knife Damage Multi

* **Change Log:**
  * 1.0:
    - First Release

  * 1.1:
    - Fixed Ambience
    - Added p_model
    
### Download Resources: https://github.com/PerfectScrash/ZP-Special-Mods/raw/master/Priest/resources.zip
