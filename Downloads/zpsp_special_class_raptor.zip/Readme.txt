## [ZPSp] Special Class: Raptor

* **Description:**
  Can run very faster for a few seconds

* **Cvars:**<br/>
  zp_raptor_minplayers "2" - Min Players for start a mod<br/>
  zp_raptor_damage "500" - Knife Damage<br/>
  zp_raptor_speed_skill "1500.0" -  Raptor Skill Speed<br/>
  zp_raptor_skill_cooldown "10.0" - Raptor Skill Cooldown<br/>
  zp_raptor_skill_time "6.0" - Raptor Skill Time

* **Change log:**
  * 1.0: 
    - First Release

  * 1.1:
    - Fixed Ambience
    - Otimized Code
    
### Download Resources: https://github.com/PerfectScrash/ZP-Special-Mods/raw/master/Raptor/resources.zip
