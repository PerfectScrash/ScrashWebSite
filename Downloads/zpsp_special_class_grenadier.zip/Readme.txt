## [ZPSp] Special Class: Grenadier

* **Description:**
    Its like a Bombardier but its human.

* **Cvars:** <br/>
    zp_grenadier_minplayers "2" - Min Players for Start a Grenadier Mod <br/>
    zp_grenadier_damage_multi "1.5" - Knife Damage Multi

* **Change Log:**
    * 1.0:
      First Release
      
## [ZPSp] Game Mode: Grenadier Vs Bombardier

* **Description:**
        Its a Grenade War, Just killing

* **Cvars:** <br/>
        zp_gvb_minplayers "2" - Min Players for Start Mod<br/>
        zp_gvb_grenadier_hp "2000" - Health of Grenadier<br/>
        zp_gvb_bombardier_hp "1000" - Health of Bombardier<br/>
        zp_gvb_inf_ratio "0.5" - Ratio of Players (0.5 with 10 players = 5 Bombardier vs 5 Grenadier)
        
* **Change Log:**
    * 1.0:
      First Release
