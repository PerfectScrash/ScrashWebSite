# [ZPSp] Addon: First Zombie Helper

## Description:
	- For prevent a fast human win rounds, first zombie have now a helper and this helper are choosed automaticaly in infection rounds.

## Requeriments:
	- AMX 1.8.3 or higher.
	- Zombie Plague Special 4.3 or Higher

## Change Log:
	* 1.0: 
		- First Release
	* 1.1:
		- No Support more to Amx 1.8.2 or older
		- Added check player for prevent consecutives infections
	* 1.2:
		- Added Lang Support