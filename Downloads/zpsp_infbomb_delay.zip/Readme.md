# [ZPSp] Addon: Delayed Infection Bomb

### Description:
  Set a time for use a Infection Bomb Again after used in first time on current round.

### Cvars:
  zp_extra_infbomb_timer "120" - Time for use a Infection Bomb Again.

### Changelog:
```
* 1.0: 
  - First Release

* 1.1:
  - No amx 1.8.2 support
  - Added lang support
```