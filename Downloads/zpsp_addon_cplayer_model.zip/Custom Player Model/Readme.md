# [ZPSp] Plugin: Player Skins

## Description:
- Give for any user a Custom Player Model by Nick/Ip/Steam ID/Flag Acess

### For examples for adding a Player model see zpsp_player_skins.ini

## Changelog:
```
- 1.0: 
    - First Release
- 1.1:
    Added Body/Skin support
- 1.2: 
    Fixex 0/0.mdl not found error